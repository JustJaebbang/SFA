import argparse, yaml
from pathlib import Path
import torch, torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, SequentialLR, LinearLR
from tqdm import tqdm
from .dataset import build_dataloaders
from .model import build_model, freeze_all, unfreeze_top, unfreeze_all
from .losses import FocalLoss
from .utils import set_seed, ensure_dir, macro_f1, plot_confusion

@torch.no_grad()
def evaluate(model, loader, device):
    model.eval(); ys, ps = [], []
    for x,y in tqdm(loader, leave=False):
        x = x.to(device); pred = model(x).argmax(1).cpu()
        ys.append(y); ps.append(pred)
    import numpy as np
    return np.concatenate(ys), np.concatenate(ps)

def main(cfg):
    set_seed(cfg["seed"])
    device = torch.device("cuda" if (cfg["device"]=="cuda" or (cfg["device"]=="auto" and torch.cuda.is_available())) else "cpu")
    ensure_dir(cfg["paths"]["runs_dir"])

    tr, va, _, classes = build_dataloaders(cfg["data"]["root"], cfg["data"]["img_size"],
                                           cfg["data"]["batch_size"], cfg["data"]["num_workers"],
                                           sampler=cfg["train"]["sampler"])
    model = build_model(len(classes)).to(device)
    freeze_all(model)

    crit = FocalLoss(gamma=cfg["train"]["focal_gamma"]) if cfg["train"]["use_focal"]            else nn.CrossEntropyLoss(label_smoothing=cfg["train"]["label_smoothing"])
    opt = AdamW(filter(lambda p: p.requires_grad, model.parameters()),
                lr=cfg["train"]["lr"], weight_decay=cfg["train"]["weight_decay"])

    total_ep = cfg["train"]["epochs_head"]+cfg["train"]["epochs_partial"]+cfg["train"]["epochs_full"]
    warm = LinearLR(opt, start_factor=0.1, total_iters=cfg["train"]["warmup_epochs"]) if cfg["train"]["warmup_epochs"]>0 else None
    cos = CosineAnnealingLR(opt, T_max=max(1,total_ep-(cfg["train"]["warmup_epochs"] or 0)))
    schedulers = [cos] if warm is None else [warm, cos]
    milestones = [] if warm is None else [cfg["train"]["warmup_epochs"]]
    sch = SequentialLR(opt, schedulers, milestones=milestones)

    best_f1, best_path = -1.0, Path(cfg["paths"]["runs_dir"]) / cfg["paths"]["ckpt_name"]

    def fit(epochs):
        nonlocal best_f1
        for _ in range(epochs):
            model.train()
            for x,y in tqdm(tr, leave=False):
                x,y = x.to(device), y.to(device)
                opt.zero_grad(); logits = model(x); loss = crit(logits, y); loss.backward(); opt.step()
            y_true, y_pred = evaluate(model, va, device)
            f1 = macro_f1(y_true, y_pred); sch.step()
            print(f"val MacroF1={f1:.4f}")
            if f1>best_f1: best_f1 = f1; torch.save({"model":model.state_dict(),"classes":classes}, best_path)

    # Stages
    fit(cfg["train"]["epochs_head"])
    unfreeze_top(model, ratio=0.33); fit(cfg["train"]["epochs_partial"])
    unfreeze_all(model); fit(cfg["train"]["epochs_full"])
    print("Best MacroF1:", best_f1, "Saved:", best_path)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="configs/config.yaml")
    args = ap.parse_args(); cfg = yaml.safe_load(open(args.config,"r"))
    main(cfg)
